class sphere:

  def __init__(self,radius = 0):
    self.radius = 0
  
  def surfacearea (self):
    r = self.radius
    surfacearea = 4*3.1415*(r**2)
    return surfacearea
  
  def volume (self):
    r = self.radius
    vol = (4/3)*3.1415*(r**3)
    return vol
    