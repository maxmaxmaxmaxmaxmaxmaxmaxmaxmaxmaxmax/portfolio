class cube:

  def __init__(self,height = 0, width = 0, length = 0):
    self.radius = 0
  
  def surfacearea (self):
    w = self.width
    l = self.length
    h = self.height
    surfacearea = 2*(l*w)*2*(l*h)*2*(h*w)
    return surfacearea
  
  def volume (self):
    w = self.width
    l = self.length
    h = self.height
    vol = w*l*h
    return vol