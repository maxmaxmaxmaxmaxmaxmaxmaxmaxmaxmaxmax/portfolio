import math
class pyrimid:
  import math

  def __init__(self,height = 0, width = 0, length = 0):
    self.radius = 0
  
  def surfacearea (self):
    w = self.width
    l = self.length
    h = self.height
    surfacearea = l*w+l*math.sqrt((w/2)**2+h**2)+w*math.sqrt((l/2)**2+h**2)
    return surfacearea
  
  def volume (self):
    w = self.width
    l = self.length
    h = self.height
    vol = (w*l*h)/3
    return vol




