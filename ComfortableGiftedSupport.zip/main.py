import sphere
import cube
import pyrimid
h = 1

print("press numbers 1-3 keys to change mode, 1=rectangle, 2=triangle, 3=circle")
h = int(input("select mode:"))
if h == 3:
  shape = sphere.sphere()
 
  r = int(input("enter redius:"))
  shape.radius = r
  
  area = shape.surfacearea()
  volume = shape.volume()
  print("arear",area)
  print("voulome",volume)

if h == 1:
  shape = cube.cube()
 
  
  w = int(input("enter width"))
  l = int(input("enter length"))
  h = int(input("enter height"))
  shape.width = w
  shape.height = h
  shape.length = l
  
  area = shape.surfacearea()
  volume = shape.volume()
  print("arear",area)
  print("voulome",volume)


if h == 2:
  shape = pyrimid.pyrimid()
 
  
  w = int(input("enter width"))
  l = int(input("enter length"))
  h = int(input("enter height"))
  shape.width = w
  shape.height = h
  shape.length = l
  
  area = shape.surfacearea()
  volume = shape.volume()
  print("arear",area)
  print("voulome",volume)
